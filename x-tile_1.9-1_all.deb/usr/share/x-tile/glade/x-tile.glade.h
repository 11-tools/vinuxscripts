char *s = N_("\n"
             "This program is free software; you can redistribute it and/or modify\n"
             "it under the terms of the GNU General Public License as published by\n"
             "the Free Software Foundation; either version 2 of the License, or\n"
             "(at your option) any later version.\n"
             "\n"
             "This program is distributed in the hope that it will be useful,\n"
             "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
             "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
             "GNU General Public License for more details.\n"
             "\n"
             "You should have received a copy of the GNU General Public License\n"
             "along with this program; if not, write to the Free Software\n"
             "Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,\n"
             "MA 02110-1301, USA.");
char *s = N_(" Language ");
char *s = N_("1) Tile Some Windows Manually");
char *s = N_("2) Select Them in the X Tile Windows List");
char *s = N_("3) Click the Update Button");
char *s = N_("<b>Custom Tiling Layout</b>");
char *s = N_("A Gnome Applet to Tile the Opened Windows");
char *s = N_("About X Tile");
char *s = N_("Add Row");
char *s = N_("Add an Application Filter");
char *s = N_("Cancel");
char *s = N_("Chinese Simplified (zh_CN) Khi-yuan Fan <Fan.khiyuan@gmail.com>\n"
             "Chinese Traditional (zh_TW) Yan-ren Tsai <elleryq@gmail.com>\n"
             "Spanish (es_AR) MeloPixel <melopixel@gmail.com>\n"
             "French (fr) Ludovic Troisi <axalis@cegetel.net>\n"
             "German (de) Jöran Zeller <joeran@zeller.ws>\n"
             "Italian (it) Giuseppe Penone <giuspen@gmail.com>\n"
             "Russian (ru) Andriy Kovtun <kovtunos@yandex.ru>");
char *s = N_("Close");
char *s = N_("Copyright © 2009-2011\n"
             "Giuseppe Penone <giuspen@gmail.com>\n"
             "Chris Camacho <chris_camacho@yahoo.com>");
char *s = N_("Do Not List Minimized Windows");
char *s = N_("Exit After Tile");
char *s = N_("Height");
char *s = N_("Hide the Vertical ButtonBox");
char *s = N_("Move the Selected Row Down");
char *s = N_("Move the Selected Row Up");
char *s = N_("OK");
char *s = N_("Only Current Workspace");
char *s = N_("Override Monitor 1 Tiling Area");
char *s = N_("Override Monitor 2 Tiling Area");
char *s = N_("Position");
char *s = N_("Preferences");
char *s = N_("Remove an Application Filter");
char *s = N_("Remove the Selected Row");
char *s = N_("Rows to Filter");
char *s = N_("Rows to be Selected by Default");
char *s = N_("Show Toolbar");
char *s = N_("Show Windows Sorting Buttons");
char *s = N_("Size");
char *s = N_("Update");
char *s = N_("Use Drag and Drop to Sort the Rows");
char *s = N_("Width");
char *s = N_("X");
char *s = N_("X Tile");
char *s = N_("Y");
char *s = N_("http://www.giuspen.com/x-tile/");
